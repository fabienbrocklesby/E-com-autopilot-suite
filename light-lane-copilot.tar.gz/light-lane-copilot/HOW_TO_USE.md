# How to use this Copilot setup

This bundle turns VS Code Copilot into a project-aware teammate that knows the e-com-autopilot-suite codebase, the playbook architecture we're moving to, and how to execute each phase of work.

## What's in this bundle

```
.github/
  copilot-instructions.md          # Always-on context for every chat
  instructions/
    backend.instructions.md        # Loaded for api/** files
    frontend.instructions.md       # Loaded for frontend/** files
    sql.instructions.md            # Loaded for *.sql files
  prompts/
    phase-0-bleeding.prompt.md     # /phase-0-bleeding
    phase-1-cleanup.prompt.md      # /phase-1-cleanup
    phase-2-engine.prompt.md       # /phase-2-engine
    phase-3-ui.prompt.md           # /phase-3-ui
    phase-4-migration.prompt.md    # /phase-4-migration
    new-step-handler.prompt.md     # /new-step-handler
    new-migration.prompt.md        # /new-migration
    new-svelte-page.prompt.md      # /new-svelte-page
    debug-thread.prompt.md         # /debug-thread
    review-changes.prompt.md       # /review-changes
    update-task-log.prompt.md      # /update-task-log
  agents/
    planner.agent.md               # @planner
    backend-implementer.agent.md   # @backend-implementer
    frontend-implementer.agent.md  # @frontend-implementer
    db-architect.agent.md          # @db-architect
    reviewer.agent.md              # @reviewer
    debugger.agent.md              # @debugger
.vscode/
  mcp.json                         # MCP server config (merge with yours)
docs/
  PLAYBOOK_ENGINE.md               # The architectural reference document
  TASK_LOG.md                      # Living doc of progress, decisions
skills/
  playbook-step/SKILL.md           # How to add a new step type
  migration-writer/SKILL.md        # Postgres migration conventions
  deno-hono-route/SKILL.md         # How to add a Hono route properly
  svelte5-page/SKILL.md            # SvelteKit 5 runes + page conventions
```

## Setup (one-time, 10 minutes)

1. **Drop the bundle into the repo root.** Copy `.github/`, `.vscode/`, `docs/`, and `skills/` into `e-com-autopilot-suite/`.

2. **Merge `.vscode/mcp.json` with your existing one.** If you already have one, copy the new server entries in. If not, just use this file as-is.

3. **Add the Postgres MCP server.** Run in VS Code:
   - Cmd+Shift+P → `MCP: Add Server`
   - Pick `@modelcontextprotocol/server-postgres`
   - Connection string: `postgres://postgres:postgres@localhost:5432/autopilot` (adjust to your local Docker setup)

4. **Verify Copilot is reading the instructions.** Open Copilot Chat, ask "what stack does this project use?" — it should mention Deno, Hono, Postgres, SvelteKit 5. If not, the instructions aren't being picked up. Check that `.github/copilot-instructions.md` exists at repo root.

5. **Verify agents are loaded.** Type `@` in chat. You should see `@planner`, `@backend-implementer`, etc.

6. **Verify prompts are loaded.** Type `/` in chat. You should see `/phase-0-bleeding`, etc.

## The workflow

### When starting a phase

```
/phase-0-bleeding
```

This loads the phase brief. Copilot will produce a checklist, ask for any missing context, then start working through it. It will edit code, run tests, update `docs/TASK_LOG.md` as it goes.

### When you want to plan before doing

```
@planner

I want to start phase 2 but I'm worried about backwards compat with existing
threads. Walk me through the migration strategy and where the failure modes are.
```

The planner agent has read-only tools — it can analyse but not edit. Forces a thinking pass before code.

### When you want focused implementation

```
@backend-implementer

Implement the playbook_runs table from docs/PLAYBOOK_ENGINE.md and the basic
StepExecutor service. Skip the step handlers for now, just the dispatch loop.
```

Backend agent only touches `api/**`. Won't accidentally edit frontend.

### When you want a sanity check

```
@reviewer

Review the diff in api/services/step-executor.ts against docs/PLAYBOOK_ENGINE.md.
Flag anything that violates the architecture or that I'd regret in 3 months.
```

Reviewer agent is read-only. Pure feedback.

### When something's broken

```
/debug-thread thread_id=42
```

Loads the debug-thread prompt, which uses the Postgres MCP to inspect the actual thread state and walk through what should have happened.

## Daily rhythm

- Start the day: `@planner` — "what's the smallest next step?"
- Do the work: `@backend-implementer` or `@frontend-implementer`
- End of session: `/update-task-log` — keeps the living doc current
- Before commits: `/review-changes`

## What this setup will NOT do for you

- Make architectural decisions you haven't made. The instructions reflect decisions in `docs/PLAYBOOK_ENGINE.md`. If that doc is wrong, Copilot will faithfully build the wrong thing.
- Catch domain logic bugs. It will write code that compiles and matches patterns. You still need to test against real emails and real customer flows.
- Replace your judgment. Treat Copilot's output as a fast junior dev's output: usually right, sometimes confidently wrong, always worth a second look.

## When to update this bundle

- You change architecture → update `docs/PLAYBOOK_ENGINE.md` and `.github/copilot-instructions.md`
- You finish a phase → archive the prompt file or mark it done in `TASK_LOG.md`
- You discover a recurring task → add a prompt file or skill for it
- You make a per-area convention decision (e.g. "all routes use this validation pattern") → add it to the relevant `*.instructions.md`
